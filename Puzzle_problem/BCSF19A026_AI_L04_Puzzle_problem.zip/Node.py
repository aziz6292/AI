class Node:
    def __init__(self, state=None, action=None, parent=None, cost=None):
        self.__state= state
        self.__action = action
        self.__parent = parent
        self.__cost = cost

    @property
    def state(self):
        return self.__state

    @property
    def action(self):
        return self.__action

    @property
    def parent(self):
        return self.__parent

    @property
    def cost(self):
        return self.__cost

    @state.setter
    def status(self, state):
        self.__state = state

    @action.setter
    def action(self, action):
        self.__action = action

    @parent.setter
    def parent(self, parent):
        self.__parent = parent

    @cost.setter
    def cost(self, cost):
        self.__cost = cost

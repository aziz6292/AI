class Problem:
    def __init__(self, initial_state, goal_state, path_cost):
        self.initial_state = initial_state
        self.goal_state = goal_state    
        self.path_cost = path_cost

    def goal_test(self,state):
        return state == self.goal_state
    def actions(self, original_state):
        x = None
        y = None
        print("current state is below")
        d = len(original_state[0])
        for i in range(d):
            print(original_state[i])
        for i in range(d):
            for j in range(d):
                if original_state[i][j] == 0:
                    x = i
                    y = j
        print(f"x={x}, y={y}")
        actions_list = []
        state1 = [[0 for _ in range(d)] for _ in range(d)]
        state2 = [[0 for _ in range(d)] for _ in range(d)]
        state3 = [[0 for _ in range(d)] for _ in range(d)]
        state4 = [[0 for _ in range(d)] for _ in range(d)]
        for i in range(d):
            for j in range (d):
                state1[i][j]= original_state[i][j]
                state2[i][j] = original_state[i][j]
                state3[i][j] = original_state[i][j]
                state4[i][j] = original_state[i][j]
        if ( y > 0 ):
            state1[x][y] = state1[x][y -1]
            state1[x][y - 1] = 0

            actions_list.append([state1, 'left'])
        if (y < d - 1): # d = dimension
            state2[x][y] = state2[x][y+1]
            state2[x][y+1] = 0

            actions_list.append([state2, 'right'])
        if ( x > 0 ):
            state3[x][y] = state3[x - 1][y ]
            state3[x -1][y ] = 0

            actions_list.append([state3, 'up'])
        if (x < d - 1): # d = dimention
    
            state4[x][y] = state4[x + 1][y]
            state4[x + 1][y] = 0
            actions_list.append([state4, 'down'])
        print("Possible Child states are below")
        size = len(actions_list)
        for j in range (d):
            for i in range (size):
                print(actions_list[i][0][j], end= '\t\t')
            print()
        print("\n\n")
        return actions_list